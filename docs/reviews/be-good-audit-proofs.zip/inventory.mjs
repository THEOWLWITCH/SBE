import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
const root = path.resolve(process.argv[2]);
const out = path.resolve(process.argv[3]);
const list = (dir) => fs.readdirSync(dir,{withFileTypes:true}).flatMap(x => x.isDirectory() ? list(path.join(dir,x.name)) : [path.join(dir,x.name)]);
const files = list(root);
const rel = file => path.relative(root,file).replaceAll('\\','/');
const syntax = [], errors = [], missing = [];
const html = files.filter(f => /\.html$/.test(f));
const js = files.filter(f => /\.(?:mjs|js)$/.test(f));
function check(file, code, module, label) {
  const result = code == null ? spawnSync(process.execPath,['--preserve-symlinks','--preserve-symlinks-main','--check',file],{encoding:'utf8'}) : spawnSync(process.execPath,['--check','--input-type',module?'module':'commonjs'],{input:code,encoding:'utf8'});
  syntax.push(label);
  if(result.status !== 0) errors.push({file:label,error:result.stderr.trim()});
}
for(const file of js) check(file,null,false,rel(file));
for(const file of html) {
  const text=fs.readFileSync(file,'utf8'); let i=0;
  for(const match of text.matchAll(/<script\b([^>]*)>([\s\S]*?)<\/script\s*>/gi)) {
    if(/\bsrc\s*=/.test(match[1]) || /type\s*=\s*["'](?:application\/ld\+json|application\/json|text\/template)/.test(match[1]) || !match[2].trim()) continue;
    check(file,match[2],/type\s*=\s*["']module["']/.test(match[1]),rel(file)+':inline-'+(++i));
  }
  for(const match of text.matchAll(/\b(?:href|src)\s*=\s*["']([^"']+)["']/gi)) {
    const value=match[1];
    if(/^(?:#|[a-z]+:|\/\/)|[${}]/i.test(value)) continue;
    let pathname=value.split(/[?#]/)[0]; if(!pathname) continue;
    try{pathname=decodeURIComponent(pathname);}catch{}
    const dest=pathname.startsWith('/')?path.join(root,'app',pathname):path.resolve(path.dirname(file),pathname);
    if(!fs.existsSync(dest) && !fs.existsSync(dest+'.html') && !fs.existsSync(path.join(dest,'index.html'))) missing.push({file:rel(file),line:text.slice(0,match.index).split('\n').length,url:value});
  }
}
const result={snapshot:'583bac5fe79bde02e7103c0ac7d8a751a08f5dbf',node:process.version,htmlFiles:html.length,scriptFiles:js.length,syntaxChecks:syntax.length,syntaxErrors:errors,missingLocalReferences:missing,largestHtml:html.map(f=>({file:rel(f),lines:fs.readFileSync(f,'utf8').split('\n').length})).sort((a,b)=>b.lines-a.lines).slice(0,8)};
fs.writeFileSync(out,JSON.stringify(result,null,2));
console.log(JSON.stringify(result));
