// Read-only audit proof against an immutable source snapshot. All data and providers are synthetic.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { Readable } from 'node:stream';
import { createHmac } from 'node:crypto';
const root = pathToFileURL(path.resolve(process.argv[2] || '.') + path.sep);
const {handleAccess} = await import(new URL('harness/lib/access.mjs', root));
const out=[];
const clone=x=>x==null?x:structuredClone(x);
const mkStore=()=>{
  const map=new Map([
    ['token-secret',{secret:'synthetic-audit-secret'}],
    ['institutions',[{name:'Audit A',code:'100001',active:true},{name:'Audit B',code:'100002',active:true}]],
    ['modules:Audit A',{journey:true,fac_trainee:true,resilience:true,academic:true,lecturer:true}],
    ['modules:Audit B',{journey:true,fac_trainee:true,resilience:true,academic:true,lecturer:true}],
    ['code:AAAA1111',{code:'AAAA1111',kind:'staff',inst:'Audit A',perms:['journey','fac_trainee','resilience']}],
    ['code:STUD1111',{code:'STUD1111',kind:'student',inst:'Audit A',perms:['academic'],uses:0,maxUses:1}]
  ]);
  return {map,async get(k){return clone(map.get(k)||null)},async set(k,v){map.set(k,clone(v))},async del(k){map.delete(k)},async list(p){return [...map].filter(([k])=>k.startsWith(p)).map(([key,value])=>({key,value:clone(value)}))},async delPrefix(p){for(const k of map.keys())if(k.startsWith(p))map.delete(k)}};
};
const call=(s,action,x={})=>handleAccess(s,{action,...x});
const login=async(s,secret)=>(await call(s,'login',{kind:'code',secret}))[1].token;
const sysToken=()=>{
 const body=Buffer.from(JSON.stringify({k:'sys',exp:Date.now()+3600000})).toString('base64url');
 return body+'.'+createHmac('sha256','synthetic-audit-secret').update(body).digest('base64url');
};
// 1: A user of another legacy institution can read the first institution's journey and workshop.
{
 const s=mkStore(),a=await login(s,'100001'),b=await login(s,'100002');
 const [cs,c]=await call(s,'jrCreate',{token:a,unit:'school',unitName:'Synthetic institution A',by:'Synthetic person A'});assert.equal(cs,200);
 const [gs,g]=await call(s,'jrGet',{token:b,id:c.id});assert.equal(gs,200);assert.equal(g.journey.inst,'Audit A');
 await call(s,'wfOpen',{token:a,w:'auditw001',inst:'Audit A'});
 const [ls,list]=await call(s,'wfList',{token:b});assert.equal(ls,200);assert.equal(list.items.length,1);assert.equal(list.items[0].inst,'Audit A');
 const [ds]=await call(s,'wfDelete',{token:b,w:'auditw001'});assert.equal(ds,200);
 out.push({proof:'legacy-cross-institution',journeyRead:gs,workshopList:ls,workshopDelete:ds});
}
// 2: A revoked code retains access to journey read/mutation and workshop creation.
{
 const s=mkStore(),token=await login(s,'AAAA1111');
 const [,c]=await call(s,'jrCreate',{token,unit:'school',unitName:'Synthetic journey'});
 const rec=await s.get('code:AAAA1111');rec.revoked=true;await s.set('code:AAAA1111',rec);
 const [r]=await call(s,'jrGet',{token,id:c.id});
 const [w]=await call(s,'wfOpen',{token,w:'auditw002'});
 const [m]=await call(s,'jrSaveMapping',{token,id:c.id,mapping:{notes:'written after revocation'}});
 const [l]=await call(s,'login',{kind:'code',secret:'AAAA1111'});
 assert.deepEqual([r,w,m,l],[200,200,200,403]);
 out.push({proof:'revocation-not-live',journeyRead:r,workshopCreate:w,journeyWrite:m,freshLogin:l});
}
// 3: Two concurrent feedback submissions both succeed but one record is lost; same race bypasses one-use quota.
{
 const s=mkStore(),token=await login(s,'AAAA1111');await call(s,'wfOpen',{token,w:'auditw003'});
 const a=await Promise.all([call(s,'wfSubmit',{w:'auditw003',role:'trainee',record:{answer:'A'}}),call(s,'wfSubmit',{w:'auditw003',role:'obs',record:{answer:'B'}})]);
 assert.equal(a[0][0],200);assert.equal(a[1][0],200);const ws=await s.get('wf:auditw003');assert.equal(ws.entries.length,1);
 const st=await login(s,'STUD1111'),q=await Promise.all([call(s,'codeUse',{token:st}),call(s,'codeUse',{token:st})]);
 assert.equal(q[0][0],200);assert.equal(q[1][0],200);assert.equal((await s.get('code:STUD1111')).uses,1);
 out.push({proof:'lost-update',feedbackSuccesses:2,feedbackStored:ws.entries.length,quotaSuccesses:2,quotaStoredUses:1});
}
// 4: Oversized journey mapping returns success without persisting the change.
{
 const s=mkStore(),token=await login(s,'AAAA1111');const [,c]=await call(s,'jrCreate',{token,unitName:'Synthetic size test'});
 const mapping={first:Array(80).fill('x'.repeat(4000)),second:Array(30).fill('y'.repeat(4000))};
 const [status,res]=await call(s,'jrSaveMapping',{token,id:c.id,mapping});
 assert.equal(status,200);assert.equal(res.ok,true);assert.deepEqual((await s.get('jr:'+c.id)).mapping,{});
 out.push({proof:'false-save',inputBytes:Buffer.byteLength(JSON.stringify(mapping)),returnedStatus:status,returnedOk:res.ok,storedMapping:'empty'});
}
// 5: Consent-based "anonymous" research export retains identifying text verbatim.
{
 const s=mkStore(),token=await login(s,'AAAA1111');const [,c]=await call(s,'jrCreate',{token,unitName:'Synthetic research institution',research:true});
 await call(s,'jrSetProposal',{token,id:c.id,proposal:{}});
 const identifier='Synthetic pupil Dana Example, class 4B, telephone 050-0000000';
 const [ss]=await call(s,'jrSubmitChoices',{token,id:c.id,choices:{decision:{option:'A',reasons:[],explain:identifier,who:['צוות']}},plan:{}});assert.equal(ss,200);
 const [es,ex]=await call(s,'jrExport',{token:sysToken()});assert.equal(es,200);assert.equal(ex.rows[0].explain,identifier);
 out.push({proof:'research-export-unscrubbed',exportStatus:es,containsSyntheticIdentifier:true});
}
// 6: Reordering milestones attaches the old certificate to a different milestone title.
{
 const s=mkStore(),token=sysToken(),id='auditcert001';
 await s.set('jr:'+id,{id,code:'AAAA1111',status:'active',unit:'school',unitName:'Synthetic certificate',milestones:[{title:'Original approved task',stage:1,status:'approved',cert:{code:'synthetic-cert',at:'2026-10-01'}},{title:'Different pending task',stage:2,status:'open'}],thread:[],events:[]});
 const [status]=await call(s,'jrEdit',{token,id,milestones:[{title:'Different pending task',stage:2},{title:'Original approved task',stage:1}]});assert.equal(status,200);
 const [certStatus,cert]=await call(s,'jrCert',{id,code:'synthetic-cert'});assert.equal(certStatus,200);assert.equal(cert.title,'Different pending task');assert.equal(cert.stage,2);
 out.push({proof:'certificate-positional-rebinding',editStatus:status,publicCertificateTitle:cert.title,publicCertificateStage:cert.stage});
}
// 7: Exact proxy source with only external services and listening replaced by synthetic fixtures.
// No real model, no Supabase, no network listener. The original request dispatch runs unchanged.
{
 globalThis.auditProviderCalls=[];
 let source=await fs.readFile(new URL('harness/practice-server.mjs',root),'utf8');
 source=source.replace("import { createServer } from 'node:http';","const createServer = handler => { globalThis.auditHandler=handler; return {listen(){}}; };");
 source=source.replace("import { getProvider } from './lib/providers.mjs';","const getProvider=()=>({complete:async x=>{globalThis.auditProviderCalls.push(x);return {text:'synthetic answer'}}});");
 source=source.replace("import { runPipeline } from './lib/pipeline.mjs';","const runPipeline=async()=>{globalThis.auditProviderCalls.push({pipeline:true});return {};};");
 source=source.replace("import { toScenario } from './lib/to-scenario.mjs';","const toScenario=()=>({id:'synthetic',name:'synthetic'});");
 source=source.replace("import { handleAccess, supabaseStore } from './lib/access.mjs';","const handleAccess=()=>{throw Error('fixture forbids access')}; const supabaseStore=()=>globalThis.auditJobStore;");
 // Prevent even accidental environment-derived access to a real store.
 globalThis.auditSupaEnabled=false;globalThis.auditJobStore=mkStore();
 source=source.replace(/process\.env\.SUPABASE_URL/g,"(globalThis.auditSupaEnabled ? 'synthetic-url' : undefined)").replace(/process\.env\.SUPABASE_SERVICE_KEY/g,"(globalThis.auditSupaEnabled ? 'synthetic-key' : undefined)");
 await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 async function dispatch(url,payload){
   const req=Readable.from([JSON.stringify(payload)]);req.method='POST';req.url=url;req.headers={origin:'https://synthetic-untrusted.invalid'};
   let status,body;const res={writeHead(s){status=s},write(){},end(x){body=JSON.parse(x);this.writableEnded=true}};
   await globalThis.auditHandler(req,res);return {status,body};
 }
 const r=await dispatch('/api/complete',{system:'synthetic prompt',messages:[{role:'user',content:'synthetic'}],maxTokens:500000});
 assert.equal(r.status,200);assert.equal(r.body.text,'synthetic answer');assert.equal(globalThis.auditProviderCalls.length,1);assert.equal(globalThis.auditProviderCalls[0].maxTokens,500000);
 const p=await dispatch('/api/pipeline',{input:{given:{who:'synthetic'}},async:true});assert.equal(p.status,200);assert.ok(p.body.jobId);
 const poll=await dispatch('/api/pipeline-status',{jobId:p.body.jobId});assert.equal(poll.status,200);
 out.push({proof:'public-ai-proxy',noToken:true,untrustedOrigin:true,completeStatus:r.status,maxTokensPassedToProvider:500000,pipelineStatus:p.status,jobPollWithoutToken:poll.status});
 // Expired persistent result is inserted after startup cleanup, as on a server running continuously.
 globalThis.auditSupaEnabled=true;
 const oldId='00000000-0000-0000-0000-000000000008';
 await globalThis.auditJobStore.set('pj:'+oldId,{status:'done',t0:Date.now()-2*86400000,text:'synthetic private work from two days ago'});
 const old=await dispatch('/api/pipeline-status',{jobId:oldId});assert.equal(old.status,200);assert.equal(old.body.status,'done');assert.equal(old.body.text,'synthetic private work from two days ago');
 out.push({proof:'persistent-job-retention',ageDays:2,returnedStatus:old.body.status,returnedPrivateSyntheticText:true});
}
console.log(JSON.stringify({snapshot:'583bac5fe79bde02e7103c0ac7d8a751a08f5dbf',syntheticOnly:true,proofs:out},null,2));
