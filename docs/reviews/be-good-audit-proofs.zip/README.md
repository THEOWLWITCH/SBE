# Be Good — ערכת שחזור לסקירה, 06.10.2026

מאגר: https://github.com/THEOWLWITCH/SBE

**צילום בסיס מדויק:** `583bac5fe79bde02e7103c0ac7d8a751a08f5dbf` של main. התסריטים משחזרים התנהגות בעייתית באותו צילום; הצלחה שלהם פירושה שהכשל שוחזר, לא שהמוצר תקין. אחרי תיקון כתבו בדיקות רגרסיה שמצפות להתנהגות הרצויה.

## הרצה

צריך Node.js 20 ומעלה ועותק מקומי של צילום הקוד. אין צורך ב-npm install, במפתחות, ב-Supabase, בשרת פועל או ב-AI. חלצו את ה-ZIP לתיקייה נפרדת, וגשו אליה בטרמינל. החליפו `PATH_TO_SBE_SNAPSHOT` בנתיב התיקייה המכילה app/ ו-harness/ של הגרסה הנסקרת.

```powershell
node --preserve-symlinks --preserve-symlinks-main ./verify-ux.mjs "PATH_TO_SBE_SNAPSHOT"
node --preserve-symlinks --preserve-symlinks-main ./ai-education-proof.mjs "PATH_TO_SBE_SNAPSHOT"
node --preserve-symlinks --preserve-symlinks-main ./access-proof.mjs "PATH_TO_SBE_SNAPSHOT"
node --preserve-symlinks --preserve-symlinks-main ./inventory.mjs "PATH_TO_SBE_SNAPSHOT" ./inventory-rerun.json
```

אפשר לקבל צילום בלי לשנות checkout קיים באמצעות `git archive 583bac5fe79bde02e7103c0ac7d8a751a08f5dbf` ולחלץ לתיקיית בדיקה. אם הגרסה אינה קיימת מקומית, יש להביא אותה מהמאגר. אין להריץ את הערכה על פרודקשן; היא קוראת קוד מקומי בלבד.

## מה כל תסריט מוכיח

| תסריט | ממצאים בדוח | דרך הבידוד |
|---|---|---|
| verify-ux.mjs | F06, F09, F10, F11, F12 | קטעי מקור מבודדים ב-VM עם טפסים ואחסון מדומים |
| ai-education-proof.mjs | F07, F08, F15, F16; מלאי מקורות | מודולים/מתאם מקור עם ספק מדומה; אין קריאת מודל |
| access-proof.mjs | F01–F05, F13, F14, F17 | handleAccess אמיתי עם מאגר בזיכרון; נתיב שרת אמיתי כשהספק, DB והאזנה הוחלפו במדומים |
| inventory.mjs | מלאי, תחביר | node --check לקובצי JS/MJS ולסקריפטים inline; בדיקת קישורים מקומיים ראשונית |

כל שמות, קודים, סודות ודוגמאות נתונים בתסריטים סינתטיים. אין בהם סוד משתמש או צילום נתונים אמיתי. פלטי baseline.log ו-inventory.json הם פלט ההרצה על צילום הבסיס; גם שם אין נתוני אנשים. שתי הפניות מקומיות שסומנו במלאי עשויות להיות חלקי תבנית: אין להציגן ככשל מוצר בלי אימות נוסף.

**מגבלות:** בדיקות ה-VM תלויות במספרי שורות או בתבנית מקור של הגרסה הקבועה. לאחר שינוי קוד, כשל extraction אינו הוכחה שכשל המוצר תוקן או נשאר. יש להחליפן בבדיקות מודול/דפדפן יציבות. דוגמאות המקביליות ממחישות GET–שינוי–SET לא אטומי; עומס אמיתי, RLS, נגישות מלאה, איכות AI והשפעה חינוכית לא נבדקו. הסקריפטים נבדקו ב-Node v20.19.1, יציאה 0, ללא שירות חיצוני.
